import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";

import { z } from "zod";

import type { AppConfig } from "./types/index.js";

const envFilePath = resolve(process.cwd(), ".env");

function stripWrappingQuotes(value: string): string {
  if (
    (value.startsWith('"') && value.endsWith('"')) ||
    (value.startsWith("'") && value.endsWith("'"))
  ) {
    return value.slice(1, -1);
  }

  return value;
}

function loadEnvFile(): void {
  if (!existsSync(envFilePath)) {
    return;
  }

  const contents = readFileSync(envFilePath, "utf8");

  for (const rawLine of contents.split(/\r?\n/u)) {
    const line = rawLine.trim();

    if (!line || line.startsWith("#")) {
      continue;
    }

    const separatorIndex = line.indexOf("=");
    if (separatorIndex === -1) {
      continue;
    }

    const key = line.slice(0, separatorIndex).trim();
    const value = stripWrappingQuotes(line.slice(separatorIndex + 1).trim());

    if (!key) {
      continue;
    }

    process.env[key] = value;
  }
}

loadEnvFile();

const envSchema = z.object({
  NOTION_TOKEN: z.string().min(1, "NOTION_TOKEN is required"),
  NOTION_API_VERSION: z.string().min(1).default("2022-06-28"),
  NOTION_REQUESTS_DATABASE_ID: z.string().min(1, "NOTION_REQUESTS_DATABASE_ID is required"),
  NOTION_TOKENS_DATABASE_ID: z.string().min(1).optional(),
  NOTION_BROWSER_PROFILE_DIR: z.string().min(1).default("./data/notion-browser-profile"),
  NOTION_HEADLESS: z.enum(["true", "false"]).default("true").transform((value) => value === "true"),
  REQUEST_POLL_INTERVAL_MS: z.coerce.number().int().min(1000).default(15000),
  REQUEST_POLL_LIMIT: z.coerce.number().int().min(1).max(100).default(10),
  NOTION_INTEGRATION_NAME_PREFIX: z.string().min(1).default("API Access"),
  NOTION_WORKSPACE_NAME: z.string().min(1).optional(),
  NOTION_EMAIL: z.string().min(1).optional(),
  NOTION_PASSWORD: z.string().min(1).optional(),
  NOTION_LOGIN_CODE: z.string().min(1).optional(),
  SLACK_BOT_TOKEN: z.string().min(1).optional(),
});

const parsedEnv = envSchema.safeParse(process.env);

if (!parsedEnv.success) {
  const issues = parsedEnv.error.issues
    .map((issue) => `${issue.path.join(".") || "env"}: ${issue.message}`)
    .join("; ");

  throw new Error(`Invalid environment configuration: ${issues}`);
}

export const config: AppConfig = {
  notionToken: parsedEnv.data.NOTION_TOKEN,
  notionApiVersion: parsedEnv.data.NOTION_API_VERSION,
  requestsDatabaseId: parsedEnv.data.NOTION_REQUESTS_DATABASE_ID,
  browserProfileDir: parsedEnv.data.NOTION_BROWSER_PROFILE_DIR,
  headless: parsedEnv.data.NOTION_HEADLESS,
  pollIntervalMs: parsedEnv.data.REQUEST_POLL_INTERVAL_MS,
  pollLimit: parsedEnv.data.REQUEST_POLL_LIMIT,
  integrationNamePrefix: parsedEnv.data.NOTION_INTEGRATION_NAME_PREFIX,
  ...(parsedEnv.data.NOTION_WORKSPACE_NAME ? { notionWorkspaceName: parsedEnv.data.NOTION_WORKSPACE_NAME } : {}),
  ...(parsedEnv.data.NOTION_EMAIL ? { notionEmail: parsedEnv.data.NOTION_EMAIL } : {}),
  ...(parsedEnv.data.NOTION_PASSWORD ? { notionPassword: parsedEnv.data.NOTION_PASSWORD } : {}),
  ...(parsedEnv.data.NOTION_LOGIN_CODE ? { notionLoginCode: parsedEnv.data.NOTION_LOGIN_CODE } : {}),
  ...(parsedEnv.data.SLACK_BOT_TOKEN ? { slackBotToken: parsedEnv.data.SLACK_BOT_TOKEN } : {}),
};
