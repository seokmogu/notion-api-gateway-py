export interface AppConfig {
  notionToken: string;
  notionApiVersion: string;
  requestsDatabaseId: string;
  browserProfileDir: string;
  headless: boolean;
  pollIntervalMs: number;
  pollLimit: number;
  integrationNamePrefix: string;
  notionWorkspaceName?: string;
  notionEmail?: string;
  notionPassword?: string;
  notionLoginCode?: string;
  slackBotToken?: string;
}

export type QueryValue = string | number | boolean | null | undefined;

export interface NotionFetchOptions {
  method?: "GET" | "POST" | "PATCH";
  body?: unknown;
  query?: Record<string, QueryValue>;
  headers?: Record<string, string>;
}

export interface NotionFetchResult<T> {
  data: T;
  requestId: string | null;
}

export interface NotionTextChunk {
  plain_text?: string;
}

export interface NotionRichTextPropertyValue {
  type: "rich_text";
  rich_text: NotionTextChunk[];
}

export interface NotionTitlePropertyValue {
  type: "title";
  title: NotionTextChunk[];
}

export interface NotionUrlPropertyValue {
  type: "url";
  url: string | null;
}

export interface NotionSelectPropertyValue {
  type: "select";
  select: { name: string } | null;
}

export interface NotionStatusPropertyValue {
  type: "status";
  status: { name: string } | null;
}

export interface NotionDatePropertyValue {
  type: "date";
  date: { start: string; end?: string | null } | null;
}

export interface NotionCreatedByPropertyValue {
  type: "created_by";
  created_by: { id: string; name?: string | null; person?: { email?: string } };
}

export interface NotionPeoplePropertyValue {
  type: "people";
  people: Array<{ id: string; name?: string | null; person?: { email?: string } }>;
}

export interface NotionRelationPropertyValue {
  type: "relation";
  relation: Array<{ id: string }>;
}

export type NotionPropertyValue =
  | NotionRichTextPropertyValue
  | NotionTitlePropertyValue
  | NotionUrlPropertyValue
  | NotionSelectPropertyValue
  | NotionStatusPropertyValue
  | NotionDatePropertyValue
  | NotionCreatedByPropertyValue
  | NotionPeoplePropertyValue
  | NotionRelationPropertyValue
  | { type: string };

export interface NotionPageRecord {
  object: "page";
  id: string;
  url: string;
  created_time?: string;
  last_edited_time?: string;
  created_by?: { id: string; name?: string | null; person?: { email?: string } };
  properties: Record<string, NotionPropertyValue>;
}

export interface NotionDatabaseQueryResult {
  results: NotionPageRecord[];
  has_more: boolean;
  next_cursor: string | null;
}

export interface RequestRecord {
  id: string;
  title: string;
  pageUrl: string;
  canonicalPageId: string;
  requester: string;
  status: string;
}

export interface TokenRecord {
  id: string;
  title: string;
  canonicalPageId: string;
  token: string;
  integrationName: string;
  pageUrl: string;
  status: string;
}

export interface ProvisioningResult {
  integrationName: string;
  token: string;
  connected: boolean;
}
