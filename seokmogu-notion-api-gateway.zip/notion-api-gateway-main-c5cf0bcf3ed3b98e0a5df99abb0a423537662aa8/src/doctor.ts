import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { execSync } from "node:child_process";

// Load .env file before checks
const envPath = resolve(process.cwd(), ".env");
if (existsSync(envPath)) {
  for (const line of readFileSync(envPath, "utf8").split(/\r?\n/u)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const idx = trimmed.indexOf("=");
    if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim();
    let val = trimmed.slice(idx + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (key) process.env[key] = val;
  }
}

interface Check {
  name: string;
  status: "ok" | "warn" | "fail";
  detail: string;
}

const results: Check[] = [];

function check(name: string, fn: () => { status: "ok" | "warn" | "fail"; detail: string }): void {
  try {
    results.push({ name, ...fn() });
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    results.push({ name, status: "fail", detail: msg });
  }
}

// 1. Node.js version
check("Node.js version", () => {
  const version = process.version;
  const major = Number(version.slice(1).split(".")[0]);
  if (major < 18) {
    return { status: "fail", detail: `${version} (requires >= 18)` };
  }
  return { status: "ok", detail: version };
});

// 2. npm dependencies
check("Dependencies installed", () => {
  const hasNodeModules = existsSync(resolve("node_modules"));
  const hasPlaywright = existsSync(resolve("node_modules/playwright"));
  const hasZod = existsSync(resolve("node_modules/zod"));
  if (!hasNodeModules || !hasPlaywright || !hasZod) {
    return { status: "fail", detail: "Run `npm install`" };
  }
  return { status: "ok", detail: "playwright, zod installed" };
});

// 3. Playwright browsers
check("Playwright browsers", () => {
  try {
    const output = execSync("npx playwright install --dry-run 2>&1", { encoding: "utf8", timeout: 10000 });
    if (output.includes("chromium")) {
      return { status: "ok", detail: "Chromium available" };
    }
    return { status: "warn", detail: "Run `npx playwright install chromium`" };
  } catch {
    return { status: "warn", detail: "Could not verify. Run `npx playwright install chromium` if needed" };
  }
});

// 4. .env file
check(".env file", () => {
  if (!existsSync(resolve(".env"))) {
    return { status: "fail", detail: "Missing. Copy .env.example to .env and fill in values" };
  }
  return { status: "ok", detail: "Exists" };
});

// 5. Required env vars
check("NOTION_TOKEN", () => {
  const token = process.env["NOTION_TOKEN"];
  if (!token) {
    return { status: "fail", detail: "Not set in .env" };
  }
  if (!token.startsWith("ntn_") && !token.startsWith("secret_")) {
    return { status: "warn", detail: "Unexpected format (should start with ntn_ or secret_)" };
  }
  return { status: "ok", detail: `${token.slice(0, 12)}...` };
});

check("NOTION_REQUESTS_DATABASE_ID", () => {
  const id = process.env["NOTION_REQUESTS_DATABASE_ID"];
  if (!id || id === "replace-with-requests-database-id") {
    return { status: "fail", detail: "Not configured" };
  }
  return { status: "ok", detail: id };
});

// 6. Browser session
check("Browser session (storage-state.json)", () => {
  const profileDir = process.env["NOTION_BROWSER_PROFILE_DIR"] ?? "./data/notion-browser-profile";
  const statePath = resolve(profileDir, "..", "storage-state.json");
  if (!existsSync(statePath)) {
    return { status: "warn", detail: "No saved session. Run `npm run auth` to log in" };
  }
  return { status: "ok", detail: statePath };
});

// 7. Data directory
check("Data directory", () => {
  const dataDir = resolve("data");
  if (!existsSync(dataDir)) {
    return { status: "warn", detail: "Missing. Will be created on first run" };
  }
  return { status: "ok", detail: "Exists" };
});

// 8. TypeScript compilation
check("TypeScript compilation", () => {
  try {
    execSync("npx tsc --noEmit 2>&1", { encoding: "utf8", timeout: 30000 });
    return { status: "ok", detail: "No errors" };
  } catch (error) {
    const msg = error instanceof Error ? (error as { stdout?: string }).stdout ?? error.message : String(error);
    return { status: "fail", detail: msg.slice(0, 200) };
  }
});

// 9. Notion API connectivity (checked async below)

// Print results
console.log("\n  Notion API Gateway - Environment Check\n");

let hasFailure = false;
for (const r of results) {
  const icon = r.status === "ok" ? " OK " : r.status === "warn" ? "WARN" : "FAIL";
  const color = r.status === "ok" ? "\x1b[32m" : r.status === "warn" ? "\x1b[33m" : "\x1b[31m";
  console.log(`  ${color}[${icon}]\x1b[0m ${r.name}: ${r.detail}`);
  if (r.status === "fail") hasFailure = true;
}

// 9. Async Notion API check
try {
  const response = await fetch("https://api.notion.com/v1/users/me", {
    headers: {
      Authorization: `Bearer ${process.env["NOTION_TOKEN"] ?? ""}`,
      "Notion-Version": "2022-06-28",
    },
  });
  if (response.ok) {
    const data = (await response.json()) as { name?: string };
    console.log(`  \x1b[32m[ OK ]\x1b[0m Notion API: Connected as "${data.name}"`);
  } else {
    console.log(`  \x1b[31m[FAIL]\x1b[0m Notion API: ${response.status} ${response.statusText}`);
    hasFailure = true;
  }
} catch (error) {
  const msg = error instanceof Error ? error.message : String(error);
  console.log(`  \x1b[31m[FAIL]\x1b[0m Notion API: ${msg}`);
  hasFailure = true;
}

console.log();
if (hasFailure) {
  console.log("  Some checks failed. Fix the issues above before running.\n");
  process.exitCode = 1;
} else {
  console.log("  All checks passed. Ready to run.\n");
}
