const UUID_WITH_DASHES = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iu;
const UUID_WITHOUT_DASHES = /^[a-f0-9]{32}$/iu;

export function normalizePageId(pageId: string): string {
  const cleaned = pageId.trim().replaceAll("-", "").toLowerCase();

  if (!UUID_WITHOUT_DASHES.test(cleaned)) {
    throw new Error(`Invalid Notion page ID: ${pageId}`);
  }

  return `${cleaned.slice(0, 8)}-${cleaned.slice(8, 12)}-${cleaned.slice(12, 16)}-${cleaned.slice(16, 20)}-${cleaned.slice(20)}`;
}

const BLOCKED_DOMAINS = [".notion.site"];

export function extractCanonicalPageId(input: string): string {
  const trimmed = input.trim();

  for (const domain of BLOCKED_DOMAINS) {
    if (trimmed.includes(domain)) {
      throw new Error(
        `Unsupported URL: ${input}\n` +
          "notion.site 도메인은 외부 공유 링크로, API 통합 연결이 불가능합니다.\n" +
          "notion.so 도메인의 워크스페이스 내부 URL을 사용해주세요.\n" +
          "예: https://www.notion.so/worxphere/Page-Name-<page-id>",
      );
    }
  }

  if (UUID_WITH_DASHES.test(trimmed) || UUID_WITHOUT_DASHES.test(trimmed)) {
    return normalizePageId(trimmed);
  }

  const match = trimmed.match(/([a-f0-9]{32}|[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})(?=$|[?#/])/iu);
  if (match?.[1]) {
    return normalizePageId(match[1]);
  }

  const slugMatch = trimmed.match(/-([a-f0-9]{32})(?=$|[?#])/iu);
  if (slugMatch?.[1]) {
    return normalizePageId(slugMatch[1]);
  }

  throw new Error(
    `Could not extract a Notion page ID from: ${input}\n` +
      "Valid formats:\n" +
      "  - https://www.notion.so/workspace/Page-Name-<32-char-hex-id>\n" +
      "  - https://www.notion.so/<32-char-hex-id>\n" +
      "  - <32-char-hex-id> or <uuid-with-dashes>\n" +
      "Database pages, external URLs, and linked databases are not supported.",
  );
}

export function buildDeterministicIntegrationName(prefix: string, pageId: string, pageTitle: string): string {
  const title = pageTitle.trim().replace(/\s+/gu, " ").slice(0, 40);
  const suffix = normalizePageId(pageId).replaceAll("-", "").slice(0, 8);
  return `${prefix} ${title || "Untitled"} ${suffix}`;
}
