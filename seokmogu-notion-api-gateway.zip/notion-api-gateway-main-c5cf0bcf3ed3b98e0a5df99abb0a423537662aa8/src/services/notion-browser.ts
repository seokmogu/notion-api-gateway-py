import { existsSync } from "node:fs";
import { createInterface } from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { resolve } from "node:path";

import { chromium, type Browser, type BrowserContext, type Locator, type Page } from "playwright";

import { config } from "../config.js";
import type { ProvisioningResult } from "../types/index.js";

const INTEGRATIONS_URL = "https://www.notion.so/profile/integrations";
const LOGIN_URL = "https://www.notion.so/login";

function storageStatePath(): string {
  return resolve(config.browserProfileDir, "..", "storage-state.json");
}

async function firstVisible(locators: Locator[], timeoutMs = 3000): Promise<Locator | null> {
  for (const locator of locators) {
    try {
      await locator.first().waitFor({ state: "visible", timeout: timeoutMs });
      return locator.first();
    } catch {
      continue;
    }
  }

  return null;
}

async function clickOne(page: Page, label: string, locators: Locator[]): Promise<void> {
  const locator = await firstVisible(locators);
  if (!locator) {
    throw new Error(`Could not find UI control: ${label}`);
  }

  await locator.click();
}

async function fillOne(page: Page, label: string, value: string, locators: Locator[]): Promise<void> {
  const locator = await firstVisible(locators);
  if (!locator) {
    throw new Error(`Could not find input: ${label}`);
  }

  await locator.fill(value);
}

async function hasVisible(page: Page, locators: Locator[], timeoutMs = 1000): Promise<boolean> {
  const locator = await firstVisible(locators, timeoutMs);
  return locator !== null;
}

async function isLoggedIn(page: Page): Promise<boolean> {
  await page.goto(INTEGRATIONS_URL, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(1000);
  return !page.url().includes("/login");
}

async function loginIfNeeded(page: Page): Promise<void> {
  const loggedIn = await isLoggedIn(page);
  if (loggedIn) {
    return;
  }

  if (!config.notionEmail || !config.notionPassword) {
    throw new Error(
      "Notion admin session is not authenticated. Run `npm run auth` once or provide NOTION_EMAIL and NOTION_PASSWORD.",
    );
  }

  await page.goto(LOGIN_URL, { waitUntil: "domcontentloaded" });

  const emailLocators = [page.getByLabel(/email/i), page.getByPlaceholder(/email/i), page.locator('input[type="email"]')];
  const passwordLocators = [
    page.getByLabel(/password/i),
    page.getByPlaceholder(/password/i),
    page.locator('input[type="password"]'),
  ];

  await fillOne(page, "email", config.notionEmail, emailLocators);

  const passwordAlreadyVisible = await hasVisible(page, passwordLocators);
  if (!passwordAlreadyVisible) {
    await clickOne(page, "continue with email", [
      page.getByRole("button", { name: /continue with email/i }),
      page.getByRole("button", { name: /continue/i }),
      page.getByText(/continue/i),
    ]);

    await page.waitForTimeout(2000);

    const rateLimited = await hasVisible(page, [
      page.getByText(/please try again later/i),
      page.getByText(/too many attempts/i),
    ], 2000);

    if (rateLimited) {
      throw new Error(
        "Notion login blocked: 'Please try again later.' — bot detection or rate limit triggered. " +
          "Run `npm run auth` manually in a real browser, or use a saved session via `storage-state.json`.",
      );
    }
  }

  const passwordNowVisible = await hasVisible(page, passwordLocators, 3000);
  if (!passwordNowVisible) {
    throw new Error(
      "No password field appeared after entering email. " +
        "This workspace may use SSO or email-code login. " +
        "Run `npm run auth` to log in manually and save the session.",
    );
  }

  await fillOne(page, "password", config.notionPassword, passwordLocators);

  const signInClicked = await hasVisible(page, [
    page.getByRole("button", { name: /continue/i }),
    page.getByRole("button", { name: /sign in/i }),
    page.getByRole("button", { name: /log in/i }),
    page.getByText(/continue/i),
  ]);

  if (signInClicked) {
    await clickOne(page, "sign in", [
      page.getByRole("button", { name: /continue/i }),
      page.getByRole("button", { name: /sign in/i }),
      page.getByRole("button", { name: /log in/i }),
      page.locator('div[role="button"]').filter({ hasText: /continue/i }),
      page.getByText(/continue/i),
    ]);
  } else {
    await page.locator('input[type="password"]').press("Enter");
  }

  const codeLocators = [
    page.getByLabel(/code/i),
    page.getByPlaceholder(/code/i),
    page.getByPlaceholder(/인증/i),
    page.locator('input[autocomplete="one-time-code"]'),
    page.locator('input[inputmode="numeric"]'),
  ];

  const codeVisible = await hasVisible(page, codeLocators, 5000);

  if (codeVisible) {
    if (!config.notionLoginCode) {
      throw new Error(
        "Notion requires a verification code but NOTION_LOGIN_CODE is not set. " +
          "Check your email for the login code and set it in .env.",
      );
    }

    await fillOne(page, "verification code", config.notionLoginCode, codeLocators);

    if (
      await hasVisible(page, [
        page.getByRole("button", { name: /continue/i }),
        page.getByRole("button", { name: /verify/i }),
        page.getByText(/continue/i),
      ])
    ) {
      await clickOne(page, "verification submit", [
        page.getByRole("button", { name: /continue/i }),
        page.getByRole("button", { name: /verify/i }),
        page.locator('div[role="button"]').filter({ hasText: /continue|verify/i }),
        page.getByText(/continue/i),
      ]);
    } else {
      await page.locator('input').last().press("Enter");
    }
  }

  const loginDeadline = Date.now() + 45_000;
  while (Date.now() < loginDeadline) {
    await page.waitForTimeout(2000);

    const currentUrl = page.url();
    if (currentUrl.includes("/login")) {
      const needsCode = await hasVisible(page, codeLocators, 500);
      if (needsCode && !config.notionLoginCode) {
        throw new Error(
          "Notion is requesting a verification code but NOTION_LOGIN_CODE is not set. " +
            "Check your email for the login code and add it to .env.",
        );
      }
    }

    await page.goto(INTEGRATIONS_URL, { waitUntil: "domcontentloaded" });
    await page.waitForTimeout(1000);

    if (!page.url().includes("/login")) {
      return;
    }
  }

  throw new Error(
    "Timed out waiting for Notion login to complete (45s). " +
      "Possible causes: incorrect credentials, missing verification code, or bot detection. " +
      "Try running `npm run auth` in non-headless mode first.",
  );
}

async function launchPersistent(headless: boolean): Promise<BrowserContext> {
  const context = await chromium.launchPersistentContext(config.browserProfileDir, {
    headless,
    viewport: null,
    args: ["--start-maximized"],
  });

  await context.grantPermissions(["clipboard-read", "clipboard-write"], { origin: "https://www.notion.so" });
  return context;
}

async function launchEphemeral(headless: boolean): Promise<{ browser: Browser; context: BrowserContext }> {
  const statePath = storageStatePath();
  if (!existsSync(statePath)) {
    throw new Error(
      "No saved browser session found. Run `npm run auth` first to log in and save the session.",
    );
  }

  const browser = await chromium.launch({
    headless,
    args: ["--start-maximized", "--disable-blink-features=AutomationControlled"],
  });

  const context = await browser.newContext({
    storageState: statePath,
    viewport: headless ? { width: 1440, height: 900 } : null,
  });

  await context.grantPermissions(["clipboard-read", "clipboard-write"], { origin: "https://www.notion.so" });
  return { browser, context };
}

async function ensureIntegrationExists(page: Page, integrationName: string): Promise<void> {
  await page.goto(INTEGRATIONS_URL, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(1500);

  const escapedName = integrationName.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
  const existing = await firstVisible(
    [
      page.getByRole("link", { name: new RegExp(escapedName, "i") }),
      page.getByText(integrationName, { exact: true }),
    ],
    1500,
  );

  if (existing) {
    await existing.click();
    return;
  }

  await clickOne(page, "new integration", [
    page.getByRole("button", { name: /new integration/i }),
    page.getByRole("button", { name: /새 API 통합/i }),
    page.getByText(/new integration/i),
    page.getByText(/새 API 통합 만들기/i),
  ]);

  await page.waitForTimeout(1500);

  // Safety: verify we are on the new-integration form before filling
  if (!page.url().includes("/form/new-integration")) {
    throw new Error("Not on the new-integration form page. Aborting to prevent accidental edits.");
  }

  await fillOne(page, "integration name", integrationName, [
    page.getByLabel(/^name$/i),
    page.getByLabel(/이름/i),
    page.getByLabel(/API 통합 이름/i),
    page.getByPlaceholder(/name/i),
    page.getByPlaceholder(/이름/i),
    page.locator('input[type="text"]').first(),
  ]);

  // Workspace dropdown: custom Notion component near "관련 워크스페이스" / "Associated workspace" label
  const wsLabelSection = page.locator("text=/관련 워크스페이스|associated workspace/i").locator("..").locator("..");
  const workspaceDropdown = await firstVisible([
    wsLabelSection.locator('[role="button"][aria-haspopup="dialog"]'),
  ]);

  if (workspaceDropdown) {
    await workspaceDropdown.click();
    await page.waitForTimeout(1000);

    const workspaceName = config.notionWorkspaceName ?? "";
    const dialog = page.locator("[role=dialog]").last();

    if (workspaceName) {
      await clickOne(page, "workspace option", [
        dialog.getByRole("menuitem", { name: workspaceName }),
        dialog.getByRole("menuitem").filter({ hasText: workspaceName }),
      ]);
    } else {
      const firstOption = await firstVisible([
        dialog.getByRole("menuitem").first(),
      ]);

      if (firstOption) {
        await firstOption.click();
      }
    }

    await page.waitForTimeout(500);
  }

  await clickOne(page, "submit integration", [
    page.getByRole("button", { name: /submit/i }),
    page.getByRole("button", { name: /create/i }),
    page.getByRole("button", { name: /생성하기/i }),
  ]);

  await page.waitForTimeout(3000);

  // After creation, a modal appears with "API 통합 설정 구성" / "Configure integration settings"
  const configureButton = await firstVisible([
    page.getByRole("button", { name: /configure integration/i }),
    page.getByRole("button", { name: /API 통합 설정 구성/i }),
    page.getByText(/API 통합 설정 구성/i),
    page.getByText(/configure integration/i),
  ], 5000);

  if (configureButton) {
    await configureButton.click();
    await page.waitForTimeout(2000);
  }
}

async function copyIntegrationToken(page: Page): Promise<string> {
  // Reveal the token by clicking "Show" / "표시하기"
  const showButton = await firstVisible([
    page.getByRole("button", { name: /^show$/i }),
    page.getByRole("button", { name: /표시하기/i }),
    page.getByText(/^show$/i),
    page.getByText(/표시하기/),
  ]);

  if (showButton) {
    await showButton.click();
    await page.waitForTimeout(1000);
  }

  // Read token from input field (ntn_ or secret_ prefix)
  const inputs = await page.locator("input").all();
  for (const inp of inputs) {
    const value = await inp.inputValue();
    if (value.startsWith("ntn_") || value.startsWith("secret_")) {
      return value.trim();
    }
  }

  // Fallback: try clipboard copy via More menu
  const moreButton = await firstVisible([
    page.getByRole("button", { name: /^more$/i }),
    page.getByLabel(/more/i),
    page.locator('button[aria-label*="More"]').first(),
  ]);

  if (moreButton) {
    await moreButton.click();
    const copyButton = await firstVisible([
      page.getByRole("menuitem", { name: /copy internal integration token/i }),
      page.getByText(/copy internal integration token/i),
      page.getByText(/내부 통합 토큰 복사/i),
    ]);

    if (copyButton) {
      await copyButton.click();
      await page.waitForTimeout(500);
      const clipboardText = await page.evaluate(async () => navigator.clipboard.readText());
      if (clipboardText.trim()) {
        return clipboardText.trim();
      }
    }
  }

  throw new Error("Could not read the integration token. The Notion UI may have changed.");
}

export async function verifyTokenAccess(token: string, pageId: string): Promise<boolean> {
  try {
    const { notionFetch } = await import("./notion.js");
    await notionFetch(`pages/${pageId}`, token);
    return true;
  } catch {
    return false;
  }
}

export async function connectToPage(targetPageUrl: string, integrationName: string): Promise<void> {
  const statePath = storageStatePath();
  const { browser, context } = await launchEphemeral(config.headless);
  try {
    const page = await context.newPage();
    await connectIntegrationToPageImpl(page, targetPageUrl, integrationName);
    await context.storageState({ path: statePath });
  } finally {
    await context.close();
    await browser.close();
  }
}

async function connectIntegrationToPageImpl(page: Page, targetPageUrl: string, integrationName: string): Promise<void> {
  await page.goto(targetPageUrl, { waitUntil: "domcontentloaded" });

  // Wait for the page to fully render the topbar actions
  try {
    await page.waitForSelector('[aria-label="작업"], [aria-label="Actions"]', { timeout: 15000 });
  } catch {
    // Fallback: wait a fixed amount and try anyway
    await page.waitForTimeout(5000);
  }

  // Open page actions menu via "작업" (Actions) button or "..." button
  await clickOne(page, "page menu", [
    page.locator('[aria-label="작업"]'),
    page.locator('[aria-label="Actions"]'),
    page.getByRole("button", { name: /^more$/i }),
    page.getByLabel(/more/i),
    page.locator('div[role="button"][aria-label*="More"]').first(),
  ]);

  await page.waitForTimeout(1000);

  // Click "연결" (Connections) to open sub-panel
  const connectionsItem = await firstVisible([
    page.locator('.notion-overlay-container div[tabindex]').filter({ hasText: /^연결\d*$/ }),
    page.locator('.notion-overlay-container div[tabindex]').filter({ hasText: /connections/i }),
  ]);

  if (!connectionsItem) {
    throw new Error("Could not find 'Connections' menu item.");
  }

  await connectionsItem.click();
  await page.waitForTimeout(1500);

  await page.waitForTimeout(1000);

  // Click "연결 추가하기" (Add connection) to show all available integrations
  await clickOne(page, "add connection", [
    page.locator('.notion-overlay-container div[tabindex]').filter({ hasText: /연결 추가하기/ }),
    page.locator('.notion-overlay-container div[tabindex]').filter({ hasText: /add connection/i }),
  ]);

  await page.waitForTimeout(3000);

  // Find and click the target integration from the expanded list (retry with page reload if not found)
  let integrationInList = await firstVisible([
    page.locator('.notion-overlay-container div[tabindex]').filter({ hasText: integrationName }),
  ], 5000);

  if (!integrationInList) {
    // Integration might not be visible yet — close overlay, reload page, and retry
    await page.keyboard.press("Escape");
    await page.waitForTimeout(1000);
    await page.reload({ waitUntil: "domcontentloaded" });

    try {
      await page.waitForSelector('[aria-label="작업"], [aria-label="Actions"]', { timeout: 15000 });
    } catch {
      await page.waitForTimeout(5000);
    }

    await clickOne(page, "page menu", [
      page.locator('[aria-label="작업"]'),
      page.locator('[aria-label="Actions"]'),
    ]);
    await page.waitForTimeout(1000);

    const connRetry = await firstVisible([
      page.locator('.notion-overlay-container div[tabindex]').filter({ hasText: /^연결\d*$/ }),
    ]);
    if (connRetry) {
      await connRetry.click();
      await page.waitForTimeout(1500);
      await clickOne(page, "add connection retry", [
        page.locator('.notion-overlay-container div[tabindex]').filter({ hasText: /연결 추가하기/ }),
      ]);
      await page.waitForTimeout(3000);

      integrationInList = await firstVisible([
        page.locator('.notion-overlay-container div[tabindex]').filter({ hasText: integrationName }),
      ], 5000);
    }
  }

  if (!integrationInList) {
    throw new Error(`Could not find integration "${integrationName}" in the connections list.`);
  }

  await integrationInList.click();
  await page.waitForTimeout(2000);

  // Confirm access dialog if it appears (e.g., "이 페이지와 모든 하위 페이지에 액세스 허용")
  const confirmButton = await firstVisible([
    page.getByRole("button", { name: /confirm/i }),
    page.getByRole("button", { name: /확인/i }),
    page.getByRole("button", { name: /허용/i }),
  ]);

  if (confirmButton) {
    await confirmButton.click();
    await page.waitForTimeout(1000);
  }
}

export async function bootstrapAdminSession(): Promise<void> {
  const context = await launchPersistent(false);
  const page = context.pages()[0] ?? (await context.newPage());

  try {
    const dest = storageStatePath();

    async function saveAndExit(): Promise<void> {
      await context.storageState({ path: dest });
      console.log(`Session saved to ${dest}`);
    }

    // Try automatic login first if credentials are available
    if (config.notionEmail && config.notionPassword) {
      console.log("Attempting automatic login...");
      try {
        await loginIfNeeded(page);
        console.log("Automatic login succeeded.");
        await saveAndExit();
        return;
      } catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        console.log(`Automatic login failed: ${msg}`);
        console.log("Falling back to manual login in browser window...");
      }
    }

    // Manual login fallback
    await page.goto(LOGIN_URL, { waitUntil: "domcontentloaded" });
    console.log("Complete the Notion admin login in the opened browser window.");
    console.log("After logging in, navigate to: https://www.notion.so/profile/integrations");

    if (input.isTTY && output.isTTY) {
      const terminal = createInterface({ input, output });
      try {
        await terminal.question("Press Enter after the Notion session is ready. ");
      } finally {
        terminal.close();
      }

      if (await isLoggedIn(page)) {
        await saveAndExit();
        return;
      }

      throw new Error("Login not detected. Make sure you are logged in and on the integrations page.");
    }

    const deadline = Date.now() + 10 * 60 * 1000;
    while (Date.now() < deadline) {
      if (await isLoggedIn(page)) {
        console.log("Detected an authenticated Notion admin session.");
        await saveAndExit();
        return;
      }

      await page.waitForTimeout(3000);
    }

    throw new Error("Timed out waiting for Notion admin login in the browser window.");
  } finally {
    await context.close();
  }
}

export async function refreshSession(): Promise<boolean> {
  const statePath = storageStatePath();
  if (!existsSync(statePath)) {
    return false;
  }

  let browser: Browser | null = null;
  try {
    const result = await launchEphemeral(true);
    browser = result.browser;
    const page = result.context.pages()[0] ?? (await result.context.newPage());
    const loggedIn = await isLoggedIn(page);

    if (loggedIn) {
      await result.context.storageState({ path: statePath });
      console.log("Session refreshed successfully.");
    }

    await result.context.close();
    return loggedIn;
  } catch {
    return false;
  } finally {
    await browser?.close();
  }
}

export async function provisionTokenForPage(input: {
  integrationName: string;
  targetPageUrl: string;
}): Promise<ProvisioningResult> {
  const statePath = storageStatePath();
  const hasStorageState = existsSync(statePath);

  if (hasStorageState) {
    const { browser, context } = await launchEphemeral(config.headless);
    try {
      const page = context.pages()[0] ?? (await context.newPage());
      const loggedIn = await isLoggedIn(page);
      if (loggedIn) {
        await ensureIntegrationExists(page, input.integrationName);
        const token = await copyIntegrationToken(page);
        await context.storageState({ path: statePath });
        return { integrationName: input.integrationName, token, connected: false };
      }
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      console.log(`Ephemeral session failed: ${msg}. Falling back to persistent login.`);
    } finally {
      await context.close();
      await browser.close();
    }
  }

  const context = await launchPersistent(config.headless);
  try {
    const page = context.pages()[0] ?? (await context.newPage());
    await loginIfNeeded(page);
    await context.storageState({ path: statePath });
    await ensureIntegrationExists(page, input.integrationName);
    const token = await copyIntegrationToken(page);
    await context.storageState({ path: statePath });
    return { integrationName: input.integrationName, token, connected: false };
  } finally {
    await context.close();
  }
}
