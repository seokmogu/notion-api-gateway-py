import { queryDatabase, retrievePage, updatePageProperties } from "./notion.js";
import { extractCanonicalPageId } from "./page-id.js";
import { config } from "../config.js";
import type {
  NotionCreatedByPropertyValue,
  NotionDatePropertyValue,
  NotionPageRecord,
  NotionPeoplePropertyValue,
  NotionPropertyValue,
  NotionRelationPropertyValue,
  RequestRecord,
  NotionRichTextPropertyValue,
  NotionSelectPropertyValue,
  NotionStatusPropertyValue,
  NotionTitlePropertyValue,
  TokenRecord,
  NotionUrlPropertyValue,
} from "../types/index.js";

const REQUEST_STATUS_REQUESTED = "Requested";
const REQUEST_STATUS_PROCESSING = "Processing";
const REQUEST_STATUS_ISSUED = "Issued";
const REQUEST_STATUS_COMPLETED = "완료";
const REQUEST_STATUS_FAILED = "Failed";
const TOKEN_STATUS_ACTIVE = "Active";

const REQUESTS = {
  title: "조직명",
  pageUrl: "신청 페이지 링크",
  canonicalPageId: "정규 페이지 ID",
  requester: "신청자",
  status: "상태",
  issuedToken: "발급 토큰키",
  integrationName: "통합 이름",
  error: "처리 오류",
  requestedAt: "신청일자",
  completedAt: "처리 완료일시",
  connected: "연결 여부",
  retryCount: "재시도 횟수",
} as const;

const MAX_RETRY_COUNT = 3;


function propertyValue(page: NotionPageRecord, name: string): NotionPropertyValue | null {
  return page.properties[name] ?? null;
}

function isRichTextProperty(property: NotionPropertyValue): property is NotionRichTextPropertyValue {
  return property.type === "rich_text";
}

function isTitleProperty(property: NotionPropertyValue): property is NotionTitlePropertyValue {
  return property.type === "title";
}

function isUrlProperty(property: NotionPropertyValue): property is NotionUrlPropertyValue {
  return property.type === "url";
}

function isSelectProperty(property: NotionPropertyValue): property is NotionSelectPropertyValue {
  return property.type === "select";
}

function isStatusProperty(property: NotionPropertyValue): property is NotionStatusPropertyValue {
  return property.type === "status";
}

function isCreatedByProperty(property: NotionPropertyValue): property is NotionCreatedByPropertyValue {
  return property.type === "created_by";
}

function isPeopleProperty(property: NotionPropertyValue): property is NotionPeoplePropertyValue {
  return property.type === "people";
}

function isRelationProperty(property: NotionPropertyValue): property is NotionRelationPropertyValue {
  return property.type === "relation";
}

function textFromProperty(property: NotionPropertyValue | null): string {
  if (!property) {
    return "";
  }

  if (isRichTextProperty(property)) {
    return property.rich_text.map((item) => item.plain_text ?? "").join("").trim();
  }

  if (isTitleProperty(property)) {
    return property.title.map((item) => item.plain_text ?? "").join("").trim();
  }

  if (isUrlProperty(property)) {
    return property.url ?? "";
  }

  if (isSelectProperty(property)) {
    return property.select?.name ?? "";
  }

  if (isStatusProperty(property)) {
    return property.status?.name ?? "";
  }

  if (isCreatedByProperty(property)) {
    return property.created_by.person?.email ?? property.created_by.name ?? property.created_by.id;
  }

  if (isPeopleProperty(property)) {
    const first = property.people[0];
    return first?.person?.email ?? first?.name ?? first?.id ?? "";
  }

  return "";
}

function titleProperty(value: string) {
  return {
    title: [
      {
        text: {
          content: value,
        },
      },
    ],
  };
}

function richTextProperty(value: string) {
  return {
    rich_text: value
      ? [
          {
            text: {
              content: value,
            },
          },
        ]
      : [],
  };
}

function urlProperty(value: string) {
  return { url: value };
}

function statusProperty(value: string) {
  return { select: { name: value } };
}

function dateProperty(value: string) {
  return { date: { start: value } };
}

function timestamp() {
  return new Date().toISOString();
}

function parseRequestRecord(page: NotionPageRecord): RequestRecord {
  const rawPageUrl = textFromProperty(propertyValue(page, REQUESTS.pageUrl));
  const canonicalPageId = textFromProperty(propertyValue(page, REQUESTS.canonicalPageId)) || extractCanonicalPageId(rawPageUrl);
  const requester =
    textFromProperty(propertyValue(page, REQUESTS.requester)) ||
    page.created_by?.person?.email ||
    page.created_by?.name ||
    page.created_by?.id ||
    "unknown-requester";

  return {
    id: page.id,
    title: textFromProperty(propertyValue(page, REQUESTS.title)) || page.id,
    pageUrl: rawPageUrl,
    canonicalPageId,
    requester,
    status: textFromProperty(propertyValue(page, REQUESTS.status)) || REQUEST_STATUS_REQUESTED,
  };
}

function parseTokenRecord(page: NotionPageRecord): TokenRecord {
  return {
    id: page.id,
    title: textFromProperty(propertyValue(page, REQUESTS.title)) || page.id,
    canonicalPageId: textFromProperty(propertyValue(page, REQUESTS.canonicalPageId)),
    token: textFromProperty(propertyValue(page, REQUESTS.issuedToken)),
    integrationName: textFromProperty(propertyValue(page, REQUESTS.integrationName)),
    pageUrl: textFromProperty(propertyValue(page, REQUESTS.pageUrl)),
    status: textFromProperty(propertyValue(page, REQUESTS.status)) || TOKEN_STATUS_ACTIVE,
  };
}

function firstTitleFromPage(page: NotionPageRecord): string {
  for (const property of Object.values(page.properties)) {
    if (isTitleProperty(property)) {
      return property.title.map((item) => item.plain_text ?? "").join("").trim();
    }
  }

  return page.id;
}

export async function getPendingRequests(limit: number): Promise<RequestRecord[]> {
  const response = await queryDatabase(config.requestsDatabaseId, {
    filter: {
      or: [
        {
          property: REQUESTS.status,
          select: { equals: REQUEST_STATUS_REQUESTED },
        },
        {
          property: REQUESTS.status,
          select: { equals: REQUEST_STATUS_FAILED },
        },
      ],
    },
    sorts: [
      {
        property: REQUESTS.requestedAt,
        direction: "ascending",
      },
    ],
    page_size: limit,
  });

  return response.data.results.map(parseRequestRecord);
}

export async function getRequestRecord(requestId: string): Promise<RequestRecord> {
  const response = await retrievePage(requestId);
  return parseRequestRecord(response.data);
}

export async function getExistingTokenForPage(canonicalPageId: string): Promise<TokenRecord | null> {
  const response = await queryDatabase(config.requestsDatabaseId, {
    filter: {
      and: [
        {
          property: REQUESTS.canonicalPageId,
          rich_text: { equals: canonicalPageId },
        },
        {
          property: REQUESTS.status,
          select: { equals: REQUEST_STATUS_ISSUED },
        },
      ],
    },
    page_size: 1,
  });

  const first = response.data.results[0];
  return first ? parseTokenRecord(first) : null;
}

export async function markRequestProcessing(request: RequestRecord): Promise<void> {
  await updatePageProperties(request.id, {
    [REQUESTS.canonicalPageId]: richTextProperty(request.canonicalPageId),
    [REQUESTS.status]: statusProperty(REQUEST_STATUS_PROCESSING),
    [REQUESTS.error]: richTextProperty(""),
  });
}

export async function markRequestFailed(requestId: string, message: string): Promise<void> {
  const page = await retrievePage(requestId);
  const currentCount = Number(textFromProperty(propertyValue(page.data, REQUESTS.retryCount)) || "0");
  const newCount = currentCount + 1;

  await updatePageProperties(requestId, {
    [REQUESTS.status]: newCount >= MAX_RETRY_COUNT ? statusProperty("Max Retries") : statusProperty(REQUEST_STATUS_FAILED),
    [REQUESTS.error]: richTextProperty(message.slice(0, 1900)),
    [REQUESTS.retryCount]: richTextProperty(String(newCount)),
  });
}

export async function markRequestIssued(requestId: string, tokenRecord: TokenRecord, connected: boolean = false): Promise<void> {
  await updatePageProperties(requestId, {
    [REQUESTS.status]: statusProperty(REQUEST_STATUS_ISSUED),
    [REQUESTS.issuedToken]: richTextProperty(tokenRecord.token),
    [REQUESTS.integrationName]: richTextProperty(tokenRecord.integrationName),
    [REQUESTS.completedAt]: dateProperty(timestamp()),
    [REQUESTS.error]: richTextProperty(""),
    [REQUESTS.connected]: richTextProperty(connected ? "Yes" : "No"),
  });
}

export async function markRequestConnected(requestId: string): Promise<void> {
  await updatePageProperties(requestId, {
    [REQUESTS.connected]: richTextProperty("Yes"),
  });
}

export async function markRequestCompleted(requestId: string): Promise<void> {
  await updatePageProperties(requestId, {
    [REQUESTS.status]: statusProperty(REQUEST_STATUS_COMPLETED),
  });
}

export function createIssuedTokenRecord(input: {
  request: RequestRecord;
  token: string;
  integrationName: string;
  sourcePageTitle: string;
}): TokenRecord {
  const title = input.sourcePageTitle.trim() || input.request.title;
  return {
    id: input.request.id,
    title,
    canonicalPageId: input.request.canonicalPageId,
    token: input.token,
    integrationName: input.integrationName,
    pageUrl: input.request.pageUrl,
    status: TOKEN_STATUS_ACTIVE,
  };
}

export async function getIssuedRequests(limit: number): Promise<Array<RequestRecord & { integrationName: string }>> {
  const response = await queryDatabase(config.requestsDatabaseId, {
    filter: {
      property: REQUESTS.status,
      select: { equals: REQUEST_STATUS_ISSUED },
    },
    page_size: limit,
  });

  return response.data.results.map((p) => {
    const record = parseRequestRecord(p);
    return {
      ...record,
      integrationName: textFromProperty(propertyValue(p, REQUESTS.integrationName)),
    };
  });
}

export async function getPageDisplayInfo(pageId: string): Promise<{ title: string; url: string }> {
  const response = await retrievePage(pageId);
  const title = firstTitleFromPage(response.data) || response.data.url;
  return {
    title,
    url: response.data.url,
  };
}
