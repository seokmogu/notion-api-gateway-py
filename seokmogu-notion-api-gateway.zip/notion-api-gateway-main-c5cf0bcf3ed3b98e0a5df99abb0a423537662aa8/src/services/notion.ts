import { config } from "../config.js";
import type {
  NotionDatabaseQueryResult,
  NotionFetchOptions,
  NotionFetchResult,
  NotionPageRecord,
} from "../types/index.js";

const NOTION_API_BASE_URL = "https://api.notion.com/v1";

export class NotionApiError extends Error {
  status: number;
  requestId: string | null;
  details: unknown;

  constructor(status: number, message: string, requestId: string | null, details: unknown) {
    super(message);
    this.name = "NotionApiError";
    this.status = status;
    this.requestId = requestId;
    this.details = details;
  }
}

function normalizePath(path: string): string {
  return path.replace(/^\/+/u, "").replace(/^v1\//u, "");
}

function buildUrl(path: string, query?: NotionFetchOptions["query"]): URL {
  const url = new URL(`${NOTION_API_BASE_URL}/${normalizePath(path)}`);

  for (const [key, value] of Object.entries(query ?? {})) {
    if (value === null || value === undefined) {
      continue;
    }

    url.searchParams.set(key, String(value));
  }

  return url;
}

function parsePayload(rawPayload: string): unknown {
  if (!rawPayload) {
    return null;
  }

  try {
    return JSON.parse(rawPayload) as unknown;
  } catch {
    return rawPayload;
  }
}

function getErrorMessage(payload: unknown, fallback: string): string {
  if (payload && typeof payload === "object" && "message" in payload) {
    const message = payload.message;
    if (typeof message === "string" && message.length > 0) {
      return message;
    }
  }

  return fallback;
}

const MAX_RETRIES = 3;
const RETRY_BASE_MS = 1000;

function isRetryable(status: number): boolean {
  return status === 429 || status === 502 || status === 503 || status === 504;
}

function getRetryDelay(attempt: number, retryAfterHeader: string | null): number {
  if (retryAfterHeader) {
    const seconds = Number(retryAfterHeader);
    if (!Number.isNaN(seconds) && seconds > 0) {
      return Math.min(seconds * 1000, 30_000);
    }
  }

  return RETRY_BASE_MS * 2 ** attempt;
}

export async function notionFetch<T>(
  path: string,
  token: string = config.notionToken,
  options: NotionFetchOptions = {},
): Promise<NotionFetchResult<T>> {
  const url = buildUrl(path, options.query);
  const headers: Record<string, string> = {
    Authorization: `Bearer ${token}`,
    "Notion-Version": config.notionApiVersion,
    Accept: "application/json",
    ...options.headers,
  };

  if (options.body !== undefined) {
    headers["Content-Type"] = "application/json";
  }

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt += 1) {
    const response = await fetch(url, {
      method: options.method ?? "GET",
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : null,
    });

    const rawPayload = await response.text();
    const payload = parsePayload(rawPayload);
    const requestId = response.headers.get("x-request-id");

    if (response.ok) {
      return { data: payload as T, requestId };
    }

    if (isRetryable(response.status) && attempt < MAX_RETRIES) {
      const delay = getRetryDelay(attempt, response.headers.get("retry-after"));
      console.warn(`Notion API ${response.status} on ${path}. Retrying in ${delay}ms (attempt ${attempt + 1}/${MAX_RETRIES}).`);
      await new Promise((resolve) => setTimeout(resolve, delay));
      continue;
    }

    throw new NotionApiError(
      response.status,
      getErrorMessage(payload, `Notion request failed with status ${response.status}`),
      requestId,
      payload,
    );
  }

  throw new Error(`Notion API request to ${path} failed after ${MAX_RETRIES} retries.`);
}

export async function queryDatabase(
  databaseId: string,
  body: Record<string, unknown>,
): Promise<NotionFetchResult<NotionDatabaseQueryResult>> {
  return notionFetch<NotionDatabaseQueryResult>(`databases/${databaseId}/query`, config.notionToken, {
    method: "POST",
    body,
  });
}

export async function retrievePage(pageId: string): Promise<NotionFetchResult<NotionPageRecord>> {
  return notionFetch<NotionPageRecord>(`pages/${pageId}`);
}

export async function updatePageProperties(
  pageId: string,
  properties: Record<string, unknown>,
): Promise<NotionFetchResult<NotionPageRecord>> {
  return notionFetch<NotionPageRecord>(`pages/${pageId}`, config.notionToken, {
    method: "PATCH",
    body: { properties },
  });
}

export async function createDatabasePage(
  databaseId: string,
  properties: Record<string, unknown>,
): Promise<NotionFetchResult<NotionPageRecord>> {
  return notionFetch<NotionPageRecord>("pages", config.notionToken, {
    method: "POST",
    body: {
      parent: {
        database_id: databaseId,
      },
      properties,
    },
  });
}
