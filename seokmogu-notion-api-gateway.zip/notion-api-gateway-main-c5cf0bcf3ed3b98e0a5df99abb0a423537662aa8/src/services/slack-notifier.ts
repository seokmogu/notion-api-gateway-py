import { config } from "../config.js";

interface SlackUser {
  id: string;
  name: string;
}

async function slackApi<T>(method: string, body: Record<string, unknown>): Promise<T> {
  if (!config.slackBotToken) {
    throw new Error("SLACK_BOT_TOKEN is not configured.");
  }

  const response = await fetch(`https://slack.com/api/${method}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${config.slackBotToken}`,
      "Content-Type": "application/json; charset=utf-8",
    },
    body: JSON.stringify(body),
  });

  const data = (await response.json()) as { ok: boolean; error?: string } & T;
  if (!data.ok) {
    throw new Error(`Slack API ${method} failed: ${data.error ?? "unknown error"}`);
  }

  return data;
}

const EMAIL_DOMAIN_ALIASES: Record<string, string[]> = {
  "worxphere.ai": ["jobkorea.co.kr"],
  "jobkorea.co.kr": ["worxphere.ai"],
};

async function lookupByEmail(email: string): Promise<SlackUser | null> {
  try {
    const response = await fetch(`https://slack.com/api/users.lookupByEmail?email=${encodeURIComponent(email)}`, {
      headers: { Authorization: `Bearer ${config.slackBotToken}` },
    });
    const data = (await response.json()) as { ok: boolean; user?: { id: string; name: string } };
    if (data.ok && data.user) {
      return { id: data.user.id, name: data.user.name };
    }
    return null;
  } catch {
    return null;
  }
}

export async function lookupSlackUserByEmail(email: string): Promise<SlackUser | null> {
  if (!config.slackBotToken) return null;

  // Try original email first
  const user = await lookupByEmail(email);
  if (user) return user;

  // Try domain aliases
  const [localPart, domain] = email.split("@");
  if (localPart && domain) {
    const aliases = EMAIL_DOMAIN_ALIASES[domain];
    if (aliases) {
      for (const altDomain of aliases) {
        const altUser = await lookupByEmail(`${localPart}@${altDomain}`);
        if (altUser) return altUser;
      }
    }
  }

  return null;
}

export async function sendSlackDM(email: string, message: string): Promise<boolean> {
  if (!config.slackBotToken) return false;

  const user = await lookupSlackUserByEmail(email);
  if (!user) {
    console.log(`Slack user not found for email: ${email}`);
    return false;
  }

  try {
    await slackApi("chat.postMessage", {
      channel: user.id,
      text: message,
      mrkdwn: true,
    });
    console.log(`Slack DM sent to ${user.name} (${email}).`);
    return true;
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    console.log(`Slack DM failed for ${email}: ${msg}`);
    return false;
  }
}

export function formatTokenIssuedMessage(title: string, token: string, pageUrl: string): string {
  return [
    `:white_check_mark: *Notion API Token Issued*`,
    ``,
    `*Organization:* ${title}`,
    `*Token:* \`${token}\``,
    `*Page:* ${pageUrl}`,
    ``,
    `This token grants API access to the specified page and its sub-pages.`,
  ].join("\n");
}

export function formatTokenFailedMessage(title: string, error: string, pageUrl: string): string {
  return [
    `:x: *Notion API Token Request Failed*`,
    ``,
    `*Organization:* ${title}`,
    `*Page:* ${pageUrl}`,
    `*Error:* ${error}`,
    ``,
    `:information_source: *Valid page URL formats:*`,
    `- \`https://www.notion.so/workspace/Page-Name-<32-char-id>\``,
    `- \`https://www.notion.so/<32-char-id>\``,
    `- \`https://www.notion.so/workspace/Page-Name-<uuid>\``,
    ``,
    `The page must be in a workspace where the integration has access.`,
    `Database pages, linked databases, and external URLs are not supported.`,
  ].join("\n");
}

export function isSlackConfigured(): boolean {
  return Boolean(config.slackBotToken);
}
