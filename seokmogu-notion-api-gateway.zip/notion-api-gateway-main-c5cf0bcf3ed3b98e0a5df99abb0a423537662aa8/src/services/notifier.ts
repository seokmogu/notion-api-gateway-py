import { config } from "../config.js";
import { notionFetch } from "./notion.js";
import { sendSlackDM, formatTokenIssuedMessage, formatTokenFailedMessage, isSlackConfigured } from "./slack-notifier.js";
import type { NotionPageRecord, NotionPeoplePropertyValue } from "../types/index.js";

const REQUESTER_PROPERTY = "신청자";

function getRequesterUserId(page: NotionPageRecord): string | null {
  const prop = page.properties[REQUESTER_PROPERTY];
  if (!prop || prop.type !== "people") return null;

  const peopleProp = prop as NotionPeoplePropertyValue;
  return peopleProp.people[0]?.id ?? null;
}

function getRequesterEmail(page: NotionPageRecord): string | null {
  const prop = page.properties[REQUESTER_PROPERTY];
  if (!prop || prop.type !== "people") return null;

  const peopleProp = prop as NotionPeoplePropertyValue;
  return peopleProp.people[0]?.person?.email ?? null;
}

async function notifyViaNotion(requestPageId: string, userId: string, message: string): Promise<void> {
  await notionFetch("comments", config.notionToken, {
    method: "POST",
    body: {
      parent: { page_id: requestPageId },
      rich_text: [
        { type: "mention", mention: { user: { id: userId } } },
        { type: "text", text: { content: ` ${message}` } },
      ],
    },
  });
}

export async function notifyRequester(requestPageId: string): Promise<void> {
  const page = await notionFetch<NotionPageRecord>(`pages/${requestPageId}`);
  const userId = getRequesterUserId(page.data);
  const email = getRequesterEmail(page.data);

  if (!userId && !email) {
    console.log("No requester set on request page. Skipping notification.");
    return;
  }

  // Notion comment
  if (userId) {
    try {
      await notifyViaNotion(requestPageId, userId, `API 토큰이 발급되었습니다. 이 페이지의 "발급 토큰키" 필드에서 확인해주세요.`);
      console.log(`Notion comment sent to ${userId}.`);
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      console.log(`Notion comment failed: ${msg}`);
    }
  }

  // Slack DM
  if (email && isSlackConfigured()) {
    const title = page.data.properties["조직명"]?.type === "title"
      ? (page.data.properties["조직명"] as { title: Array<{ plain_text?: string }> }).title.map(t => t.plain_text ?? "").join("")
      : "";
    const token = page.data.properties["발급 토큰키"]?.type === "rich_text"
      ? (page.data.properties["발급 토큰키"] as { rich_text: Array<{ plain_text?: string }> }).rich_text.map(t => t.plain_text ?? "").join("")
      : "";
    const pageUrl = page.data.properties["신청 페이지 링크"]?.type === "url"
      ? (page.data.properties["신청 페이지 링크"] as { url: string | null }).url ?? ""
      : "";

    await sendSlackDM(email, formatTokenIssuedMessage(title, token, pageUrl));
  }
}

export async function notifyFailure(requestPageId: string, errorMessage: string): Promise<void> {
  const page = await notionFetch<NotionPageRecord>(`pages/${requestPageId}`);
  const userId = getRequesterUserId(page.data);
  const email = getRequesterEmail(page.data);

  if (!userId && !email) return;

  // Notion comment
  if (userId) {
    try {
      await notifyViaNotion(requestPageId, userId, `토큰 발급에 실패했습니다: ${errorMessage.slice(0, 200)}`);
    } catch {
      // Non-critical
    }
  }

  // Slack DM
  if (email && isSlackConfigured()) {
    const title = page.data.properties["조직명"]?.type === "title"
      ? (page.data.properties["조직명"] as { title: Array<{ plain_text?: string }> }).title.map(t => t.plain_text ?? "").join("")
      : "";
    const pageUrl = page.data.properties["신청 페이지 링크"]?.type === "url"
      ? (page.data.properties["신청 페이지 링크"] as { url: string | null }).url ?? ""
      : "";

    await sendSlackDM(email, formatTokenFailedMessage(title, errorMessage, pageUrl));
  }
}
