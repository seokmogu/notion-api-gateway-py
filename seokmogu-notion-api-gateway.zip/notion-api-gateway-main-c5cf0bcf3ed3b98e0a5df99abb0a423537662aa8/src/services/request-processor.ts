import { config } from "../config.js";
import type { RequestRecord } from "../types/index.js";
import { connectToPage, provisionTokenForPage, refreshSession, verifyTokenAccess } from "./notion-browser.js";
import {
  createIssuedTokenRecord,
  getExistingTokenForPage,
  getPendingRequests,
  getRequestRecord,
  getIssuedRequests,
  markRequestCompleted,
  markRequestConnected,
  markRequestFailed,
  markRequestIssued,
  markRequestProcessing,
} from "./notion-records.js";
import { notifyFailure, notifyRequester } from "./notifier.js";
import { sendSlackDM } from "./slack-notifier.js";

const ADMIN_EMAIL = "seokmogu@worxphere.ai";
import { buildDeterministicIntegrationName, extractCanonicalPageId } from "./page-id.js";

async function processOneRequest(request: RequestRecord): Promise<void> {
  try {
    const rawInput = request.pageUrl || request.canonicalPageId;
    if (!rawInput) {
      await markRequestFailed(request.id, "Missing both page URL and canonical page ID.");
      return;
    }

    const canonicalPageId = extractCanonicalPageId(rawInput);
    const targetPageUrl = request.pageUrl || `https://www.notion.so/${canonicalPageId.replaceAll("-", "")}`;
    const normalizedRequest: RequestRecord = {
      ...request,
      canonicalPageId,
      pageUrl: targetPageUrl,
    };

    await markRequestProcessing(normalizedRequest);

    const existingToken = await getExistingTokenForPage(canonicalPageId);
    if (existingToken) {
      const connected = await verifyTokenAccess(existingToken.token, canonicalPageId);
      await markRequestIssued(normalizedRequest.id, existingToken, connected);
      return;
    }

    const integrationName = buildDeterministicIntegrationName(
      config.integrationNamePrefix,
      canonicalPageId,
      normalizedRequest.title,
    );

    const provisioning = await provisionTokenForPage({
      integrationName,
      targetPageUrl,
    });

    const tokenRecord = createIssuedTokenRecord({
      request: normalizedRequest,
      token: provisioning.token,
      integrationName: provisioning.integrationName,
      sourcePageTitle: normalizedRequest.title,
    });

    // Verify if integration is already connected (e.g., from manual setup)
    const connected = await verifyTokenAccess(provisioning.token, canonicalPageId);
    await markRequestIssued(normalizedRequest.id, tokenRecord, connected);

    try {
      await notifyRequester(normalizedRequest.id);
      await markRequestCompleted(normalizedRequest.id);
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      console.log(`Notification failed: ${msg}`);
    }

    // Attempt page connection in background — new integrations may not appear immediately
    if (!connected) {
      try {
        await connectToPage(targetPageUrl, provisioning.integrationName);
        const nowConnected = await verifyTokenAccess(provisioning.token, canonicalPageId);
        if (nowConnected) {
          await markRequestConnected(normalizedRequest.id);
          console.log(`Connection confirmed for ${normalizedRequest.title}.`);
        }
      } catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        console.log(`Page connection deferred: ${msg}. Will retry on next cycle if status is re-queued.`);
      }
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    try {
      await markRequestFailed(request.id, message);
      await notifyFailure(request.id, message);
    } catch (updateError) {
      const updateMsg = updateError instanceof Error ? updateError.message : String(updateError);
      console.error(`Failed to mark request ${request.id} as failed: ${updateMsg}`);
    }

    // Always notify admin on unexpected errors
    try {
      await sendSlackDM(ADMIN_EMAIL, `:warning: *Token request error*\n*Request:* ${request.title || request.id}\n*Page:* ${request.pageUrl || "(no URL)"}\n*Error:* ${message.slice(0, 300)}`);
    } catch {
      // Best effort
    }
  }
}

export async function processPendingRequests(limit: number = config.pollLimit): Promise<number> {
  const requests = await getPendingRequests(limit);

  let processed = 0;
  for (const request of requests) {
    await processOneRequest(request);
    processed += 1;
  }

  return processed;
}

export async function processSpecificRequest(requestId: string): Promise<void> {
  const request = await getRequestRecord(requestId);
  await processOneRequest(request);
}

async function retryIssuedRequests(): Promise<void> {
  const issued = await getIssuedRequests(5);
  if (issued.length === 0) return;

  console.log(`Processing ${issued.length} issued but incomplete request(s).`);
  for (const request of issued) {
    const targetPageUrl = request.pageUrl || `https://www.notion.so/${request.canonicalPageId.replaceAll("-", "")}`;

    // Retry page connection if not connected
    if (request.integrationName) {
      try {
        await connectToPage(targetPageUrl, request.integrationName);
        await markRequestConnected(request.id);
        console.log(`Connected: ${request.title}`);
      } catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        console.log(`Connection retry failed for ${request.title}: ${msg}`);
      }
    }

    // Send notification and mark complete
    try {
      await notifyRequester(request.id);
      await markRequestCompleted(request.id);
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      console.log(`Notification failed for ${request.title}: ${msg}`);
    }
  }
}

const SESSION_REFRESH_INTERVAL_MS = 60 * 60 * 1000; // 1 hour

let shutdownRequested = false;

export function requestShutdown(): void {
  shutdownRequested = true;
}

export async function runPollLoop(): Promise<void> {
  let lastRefresh = 0;

  while (!shutdownRequested) {
    const now = Date.now();
    if (now - lastRefresh >= SESSION_REFRESH_INTERVAL_MS) {
      try {
        const ok = await refreshSession();
        if (!ok) {
          console.warn("Session refresh failed. Token provisioning may fail until `npm run auth` is run.");
        }
        lastRefresh = now;
      } catch {
        console.warn("Session refresh error. Will retry next cycle.");
      }
    }

    try {
      const processed = await processPendingRequests(config.pollLimit);
      if (processed === 0) {
        console.log(`No pending requests. Sleeping for ${config.pollIntervalMs}ms.`);
      } else {
        console.log(`Processed ${processed} request(s).`);
      }
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      console.error(`Poll cycle error: ${msg}. Continuing next cycle.`);
    }

    // Retry page connections for issued but unconnected requests
    try {
      await retryIssuedRequests();
    } catch {
      // Non-critical, continue
    }

    await new Promise((resolve) => setTimeout(resolve, config.pollIntervalMs));
  }
}
