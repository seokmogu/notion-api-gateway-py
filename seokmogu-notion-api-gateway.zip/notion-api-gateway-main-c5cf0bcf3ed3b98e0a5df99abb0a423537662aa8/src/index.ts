import { config } from "./config.js";
import { bootstrapAdminSession, refreshSession } from "./services/notion-browser.js";
import { notionFetch } from "./services/notion.js";
import { processPendingRequests, processSpecificRequest, requestShutdown, runPollLoop } from "./services/request-processor.js";

type FlagValue = string | boolean;

function parseFlags(argv: string[]): Map<string, FlagValue> {
  const flags = new Map<string, FlagValue>();

  for (let index = 0; index < argv.length; index += 1) {
    const current = argv[index];
    if (!current?.startsWith("--")) {
      continue;
    }

    const key = current.slice(2);
    const next = argv[index + 1];
    if (!next || next.startsWith("--")) {
      flags.set(key, true);
      continue;
    }

    flags.set(key, next);
    index += 1;
  }

  return flags;
}

function getStringFlag(flags: Map<string, FlagValue>, key: string): string | null {
  const value = flags.get(key);
  return typeof value === "string" && value.length > 0 ? value : null;
}

function printUsage(): void {
  console.log(`Usage:
  npm run auth
  npm run poll
  npm run process -- --request <request-page-id>
  npm run process
  npm run refresh`);
}

async function preflight(): Promise<void> {
  try {
    await notionFetch("users/me", config.notionToken);
  } catch {
    throw new Error(
      "NOTION_TOKEN is invalid or expired. Go to https://www.notion.so/profile/integrations, " +
        "find your integration, and copy the current Internal Integration Secret into .env.",
    );
  }

  try {
    await notionFetch(`databases/${config.requestsDatabaseId}`, config.notionToken);
  } catch {
    throw new Error(
      `NOTION_REQUESTS_DATABASE_ID (${config.requestsDatabaseId}) is not accessible. ` +
        "Check that the integration has access to this database.",
    );
  }
}

async function main(): Promise<void> {
  const [command, ...rest] = process.argv.slice(2);
  const flags = parseFlags(rest);

  switch (command) {
    case "auth": {
      await bootstrapAdminSession();
      return;
    }
    case "refresh": {
      const ok = await refreshSession();
      if (!ok) {
        console.error("Session expired or not found. Run `npm run auth` to log in.");
        process.exitCode = 1;
      }
      return;
    }
    case "poll": {
      await preflight();

      const shutdown = () => {
        console.log("\nShutdown requested. Finishing current cycle...");
        requestShutdown();
      };

      process.on("SIGINT", shutdown);
      process.on("SIGTERM", shutdown);

      await runPollLoop();
      console.log("Poll loop stopped gracefully.");
      return;
    }
    case "process": {
      await preflight();
      const requestId = getStringFlag(flags, "request");
      if (requestId) {
        await processSpecificRequest(requestId);
        return;
      }

      await processPendingRequests(1);
      return;
    }
    default: {
      printUsage();
      process.exitCode = 1;
    }
  }
}

main().catch((error: unknown) => {
  const message = error instanceof Error ? error.stack ?? error.message : String(error);
  console.error(message);
  process.exitCode = 1;
});
