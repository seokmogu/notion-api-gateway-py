# Notion Token Issuer

`notion-api-gateway` is now a local worker that watches a Notion request database and issues page-scoped Notion integration tokens through browser automation.

The new flow is:

1. A requester submits a Notion form with a target page URL.
2. The worker normalizes the page ID and checks a Notion token registry database.
3. If the page already has an issued token, the worker reuses it.
4. If the page is new, the worker opens a headless browser, creates or reopens a deterministic internal integration, adds the connection to the requested page, copies the token, stores it in the token registry DB, and writes the token back to the request row.

## What changed

The old JWT + SQLite + proxy architecture is gone.

This project no longer proxies Notion API calls. It automates the admin-only Notion UI steps that the public API cannot do:

- create internal integrations,
- add connections to pages,
- copy internal integration tokens.

All state now lives in Notion databases.

## Required Notion databases

Create two databases manually in Notion.

### 1. `노션 API 키 신청`

Use this as the Notion Form target.

Required properties:

| Property | Type | Purpose |
| --- | --- | --- |
| `조직명` | Title | 신청 대상 조직명. 실제 자동화에서는 신청 페이지 제목을 기준으로 API 키 이름을 만든다 |
| `신청 페이지 링크` | URL | 연결이 필요한 상위 조직 페이지 링크 |
| `정규 페이지 ID` | Rich text | 워커가 채우는 정규화된 Notion 페이지 ID |
| `신청자` | Rich text or People | 신청자 정보 |
| `상태` | Select | `Requested`, `Processing`, `Issued`, `Failed` |
| `발급 토큰키` | Rich text | 발급 완료 후 기록되는 최종 토큰 |
| `통합 이름` | Rich text | 자동 생성된 integration 이름 |
| `처리 오류` | Rich text | 실패 사유 |
| `신청일자` | Date | 신청 시각 |
| `처리 완료일시` | Date | 완료 시각 |

### 2. `노션 API 키 레지스트리`

Use this as the dedupe registry.

Required properties:

| Property | Type | Purpose |
| --- | --- | --- |
| `조직명` | Title | 실제 신청 페이지 제목 기반 조직명 |
| `정규 페이지 ID` | Rich text | 중복 판정 키 |
| `신청 페이지 링크` | URL | 원본 페이지 링크 |
| `발급 토큰키` | Rich text | 발급된 토큰 |
| `통합 이름` | Rich text | 연결된 integration 이름 |
| `상태` | Select | `Active` 등 라이프사이클 상태 |
| `발급일시` | Date | 생성 시각 |

## Environment

Copy `.env.example` to `.env` and fill in the values.

Important values:

- `NOTION_TOKEN`: operations token with access to the request DB, token DB, and requested pages
- `NOTION_REQUESTS_DATABASE_ID`: Notion database ID for form submissions
- `NOTION_TOKENS_DATABASE_ID`: Notion database ID for dedupe/token registry
- `NOTION_BROWSER_PROFILE_DIR`: persistent Playwright profile for the admin browser session

`NOTION_EMAIL` and `NOTION_PASSWORD` are optional fallback values for debugging. The intended operating model is **not** per-request credential login.

The intended operating model is:

1. run `npm run auth` once,
2. complete the Notion admin login manually,
3. persist the browser session in `NOTION_BROWSER_PROFILE_DIR`,
4. let `npm run poll` or `npm run process` reuse that saved session.

If your Notion login requires email MFA, treat that as a **session bootstrap / refresh** step, not as part of the normal request-processing path.

## Commands

```bash
npm install
npm run auth
npm run poll
npm run process -- --request <request-page-id>
```

### `npm run auth`

Opens a persistent Notion browser profile so you can establish the admin session used later by headless runs.

This is the normal way to operate the worker. The worker should reuse the saved session rather than logging in from scratch on every request.

### `npm run poll`

Polls the requests database forever and processes pending rows serially.

### `npm run process -- --request <request-page-id>`

Processes one specific request row.

## Dedupe behavior

The worker dedupes by normalized Notion page ID, not by raw URL string.

That means:

- repeated requests for the same page reuse the same token,
- different URL variants of the same page map to one record,
- the token registry DB is the source of truth.

## Runtime behavior

For each request:

1. Read `신청 페이지 링크`.
2. Extract the canonical page ID.
3. Mark the row as `Processing`.
4. Search the token registry for the same canonical page ID.
5. If found, write the existing token back to the request and mark `Issued`.
6. If not found, drive the Notion UI in Playwright to create/reuse the integration, connect it to the page, copy the token, create a token record, and mark the request `Issued`.
7. On failure, write the error message and mark `Failed`.

API 키 이름은 신청 row 제목이 아니라 **실제 신청 대상 페이지 제목(=조직명)** 을 기준으로 만든다.

## Important limits

- Internal integration creation is not available in the public Notion API, so browser automation is required.
- Adding `Add connection` to a page is also UI-only.
- The browser session must have enough Notion permissions to create integrations and connect them to pages.
- Tokens are intentionally stored in Notion because this redesign accepts token exposure at rest.
- If the Notion account uses email MFA, fully unattended first-time login is not realistic. Plan around persistent session reuse plus occasional manual re-auth.

## Verification

The project includes unit tests for canonical page ID parsing and deterministic integration naming. Browser automation should be verified against a real admin session after `.env` is configured.
