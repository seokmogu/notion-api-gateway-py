import { describe, expect, it } from "vitest";

import { buildDeterministicIntegrationName, extractCanonicalPageId, normalizePageId } from "../src/services/page-id.js";

describe("page-id helpers", () => {
  it("normalizes dashed and non-dashed ids", () => {
    const raw = "3197d8322b04802eaf59e199b1c7d23f";
    expect(normalizePageId(raw)).toBe("3197d832-2b04-802e-af59-e199b1c7d23f");
    expect(normalizePageId("3197d832-2b04-802e-af59-e199b1c7d23f")).toBe("3197d832-2b04-802e-af59-e199b1c7d23f");
  });

  it("extracts ids from notion urls", () => {
    const url = "https://www.notion.so/workspace/Data-Platform-Tribe-3197d8322b04802eaf59e199b1c7d23f?pvs=4";
    expect(extractCanonicalPageId(url)).toBe("3197d832-2b04-802e-af59-e199b1c7d23f");
  });

  it("builds deterministic integration names", () => {
    const name = buildDeterministicIntegrationName("API Access", "3197d8322b04802eaf59e199b1c7d23f", "Data Platform Tribe");
    expect(name).toBe("API Access Data Platform Tribe 3197d832");
  });
});
