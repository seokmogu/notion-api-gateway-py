# TDD: 노션 API 키 신청 자동화

## 1. Architecture

The application is a local TypeScript worker.

It has two system boundaries:

1. **Notion API boundary** for request and token registry data
2. **Playwright browser boundary** for admin-only Notion UI actions

```text
Notion Form -> Requests DB -> Worker
                         -> dedupe lookup in Tokens DB
                         -> if missing: Playwright browser
                         -> create/reuse integration
                         -> connect page
                         -> copy token
                         -> Tokens DB update
                         -> Request row update
```

## 2. Why this shape

The public Notion API cannot:

- create internal integrations,
- add connections to pages,
- copy internal integration tokens.

Therefore those steps must be automated in the browser.

Everything else should stay in the Notion API because it is deterministic and easier to test.

## 3. Data model

### 3.1 Requests DB

This database is the output target of the Notion form.

Required properties:

- `조직명` (title)
- `신청 페이지 링크` (url)
- `정규 페이지 ID` (rich_text)
- `신청자` (rich_text or people)
- `상태` (select)
- `발급 토큰키` (rich_text)
- `통합 이름` (rich_text)
- `처리 오류` (rich_text)
- `신청일자` (date)
- `처리 완료일시` (date)

Status values used by the worker:

- `Requested`
- `Processing`
- `Issued`
- `Failed`

### 3.2 Tokens DB

This database is the dedupe registry.

Required properties:

- `조직명` (title)
- `정규 페이지 ID` (rich_text)
- `신청 페이지 링크` (url)
- `발급 토큰키` (rich_text)
- `통합 이름` (rich_text)
- `상태` (select)
- `발급일시` (date)

The dedupe key is the `Canonical Page ID` property.

## 4. Commands

### `auth`

Opens a persistent browser profile for a one-time admin login bootstrap.

### `poll`

Queries the requests DB repeatedly and processes pending requests serially.

### `process --request <page-id>`

Processes a single request row directly.

## 5. Processing pipeline

### 5.1 Request selection

The worker queries the requests DB for rows whose `상태` is `Requested` or `Failed`.

Rows are sorted by `신청일자` ascending.

### 5.2 Canonicalization

The worker extracts a normalized page ID from the submitted URL.

Rules:

- accept dashed UUIDs,
- accept 32-char IDs,
- accept Notion URLs with slugs,
- remove fragments and query params,
- normalize to dashed lowercase UUID form.

### 5.3 Dedupe

Before any browser action, the worker queries the tokens DB for an `Active` record with the same canonical page ID.

If found, the request is fulfilled with the existing token and no new integration is created.

### 5.4 Provisioning

If no token record exists, the browser automation layer does the following:

1. Open the persistent Notion admin profile
2. Ensure the user is signed in
3. Open the integrations UI
4. Create or reopen a deterministic integration named with `prefix + requested page title + page-id suffix`
5. Copy the integration token
6. Open the requested page
7. Use `Add connections` to attach the integration to that page

The requested page title is the source of truth for the organization name used in the API key / integration naming.

### 5.5 Persistence

After a token is captured, the worker:

1. creates a token record in the tokens DB,
2. writes the token and relation back to the request row,
3. marks the request as `Issued`.

On failure, it writes the error text and marks the request `Failed`.

## 6. Acceptance criteria

1. `extractCanonicalPageId()` returns the same canonical ID for all URL variants of one page.
2. A request for a page with an existing token skips browser provisioning.
3. A request for a new page creates exactly one token record.
4. Request rows always end in one of `Issued` or `Failed`.
5. The worker never processes two requests in parallel.

## 7. Known limitations

- Browser automation depends on Notion UI stability.
- Workspace owner or equivalent permission may be required for integration creation.
- CAPTCHA, MFA, or session expiry may require periodic manual `auth` refresh.
- Tokens are intentionally stored in Notion plaintext for this redesign.

## 8. Authentication model

The worker should operate with a **reused Playwright persistent profile**.

`NOTION_EMAIL` and `NOTION_PASSWORD` exist only as a fallback for debugging or recovery. They are not the primary runtime model.

If the Notion account requires email MFA, the correct operating pattern is:

1. bootstrap the session once with `npm run auth`,
2. reuse the saved browser profile during normal request processing,
3. refresh manually only when the profile is no longer authenticated.

This avoids turning every request into a fresh interactive login flow.
