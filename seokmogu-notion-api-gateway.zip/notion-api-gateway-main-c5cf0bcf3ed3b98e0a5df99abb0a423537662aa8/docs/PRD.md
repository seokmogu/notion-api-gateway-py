# PRD: 노션 API 키 신청 자동화

## 1. Problem

Teams need a way to request Notion API access for specific pages without manually repeating the same integration setup work every time.

The target flow is:

1. 신청자가 노션 신청폼을 제출한다.
2. 요청에는 연결이 필요한 페이지 링크가 포함된다.
3. The system detects duplicate requests for the same page.
4. If a token already exists for that page, it reuses the token.
5. If not, it automatically creates the integration, connects it to the page, copies the token, and writes the token back into Notion.

## 2. Product goal

Replace the old API gateway with a **form-driven token issuance worker**.

This worker does not proxy runtime API calls. Its only job is to operationalize token issuance and reuse.

## 3. Core requirements

| ID | Requirement | Priority |
| --- | --- | :---: |
| FR-1 | Read incoming requests from a Notion form-backed database | P0 |
| FR-2 | Extract a canonical page ID from the submitted page URL | P0 |
| FR-3 | Deduplicate by canonical page ID | P0 |
| FR-4 | Reuse an existing token if that page was already processed | P0 |
| FR-5 | If no token exists, use browser automation to create/reuse the integration and connect it to the page | P0 |
| FR-6 | Copy the token and store it in a Notion token registry database | P0 |
| FR-7 | Write the final token and status back to the request row | P0 |
| FR-8 | Process requests serially to avoid duplicate token creation races | P0 |

## 4. Non-goals

- No JWT login
- No SQLite or external DB
- No runtime Notion API proxy
- No per-user auth layer
- No token encryption requirement for this phase

## 5. User flow

```text
Requester -> Notion Form -> 노션 API 키 신청 DB -> local worker
         -> dedupe by page ID
         -> existing token? yes -> write back token
         -> existing token? no  -> browser automation
                                -> create/reuse integration
                                -> add connection to requested page
                                -> copy token
                                -> store token in Team API Tokens DB
                                -> write token back to request row
```

## 6. Success criteria

| Criteria | Evidence |
| --- | --- |
| Duplicate requests for the same page do not create a second token | Same canonical page ID resolves to one token record |
| New requests create a usable token record | Token is written to the request row and token registry |
| Failures are visible to operators | Request row moves to `Failed` with error text |
| Local operation is possible without an external DB | `.env` + Notion DBs + browser profile are sufficient |

## 7. Operational assumption

This product assumes a **persistent Notion admin browser session**.

If the admin account uses email MFA, the intended model is:

- manual login once with `npm run auth`,
- session reuse for normal processing,
- manual re-auth only when the saved session expires.

It is not a design goal to perform a full MFA login flow on every request.

## 8. Current request form schema

The active intake form uses Korean properties:

- `조직명`
- `신청 페이지 링크`
- `신청자`
- `상태`
- `신청일자`
- `발급 토큰키`
- `정규 페이지 ID`
- `통합 이름`
- `처리 오류`
- `처리 완료일시`

The API key / integration naming should use the **actual requested page title** as the organization name source of truth.
